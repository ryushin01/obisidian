import SpinnerImage from "./spinner.svg";

// temp
import Image1 from "./temp/1.jpg";
import Image2 from "./temp/2.jpg";
import Image3 from "./temp/3.jpg";
import Image4 from "./temp/4.png";

export {
  SpinnerImage,

  // temp
  Image1,
  Image2,
  Image3,
  Image4,
};
