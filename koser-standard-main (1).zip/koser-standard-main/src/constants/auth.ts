export const AUTH_LIST = [
  { id: 1, name: "auth", value: "FI", labelText: "금융기관", disabled: false },
  {
    id: 2,
    name: "auth",
    value: "LA",
    labelText: "법무대리인",
    disabled: false,
  },
  {
    id: 3,
    name: "auth",
    value: "AD",
    labelText: "관리자",
    disabled: false,
  },
];