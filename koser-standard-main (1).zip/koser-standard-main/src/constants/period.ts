export const PERIOD_LIST = [
  { id: 1, content: "1일", disabled: false },
  {
    id: 2,
    content: "1주일",
    disabled: false,
  },
  {
    id: 3,
    content: "1개월",
    disabled: false,
  },
  // {
  //   id: 4,
  //   content: "기간 설정",
  //   disabled: false,
  // },
];