/**
 * @name ADBreadcrumb
 * @version 1.0.0
 * @author
 * @description 괸리자 전용 컴포넌트입니다.
 */
export default function ADBreadcrumb() {
  return (
    <ol className="_breadcrumb">
      <li>
        관리자 브레드크럼
      </li>
    </ol>
  );
}
