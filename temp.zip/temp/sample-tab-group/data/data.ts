export const TAB_LIST = [
  {
    label: "Tab1",
    content: "1번 데이터",
  },
  {
    label: "Tab2",
    content: "2번 데이터",
  },
  {
    label: "Tab3",
    content: "3번 데이터",
  },
  {
    label: "Tab4",
    content: "4번데이터",
  },
];
