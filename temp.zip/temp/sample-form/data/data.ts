export const CONUTRY_LIST = [
  {
    value: "Korea",
    label: "한국",
  },
  {
    value: "America",
    label: "미국",
  },
  {
    value: "China",
    label: "중국",
  },
  {
    value: "Japan",
    label: "일본",
  },
  {
    value: "Australia",
    label: "호주",
  },
  {
    value: "Canada",
    label: "캐나다",
  },
  {
    value: "Portugal",
    label: "포르투갈",
  },
  {
    value: "Brazil",
    label: "브라질",
  },
];
